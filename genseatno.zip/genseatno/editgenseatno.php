<?php

/**
 * @package     local_genseatno
 * @author      iqraa
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

//use local_machine\form\editcookies;
//use local_machine\manager;

require_once(__DIR__ . '/../../config.php');

require_login();
$context = context_system::instance();

//require_capability('local/mancookies:managemancookies', $context);

$PAGE->set_url(new moodle_url('/local/genseatno/editgenseatno.php'));
$PAGE->set_context(\context_system::instance());
$PAGE->set_title('gen. seatno');

$field = $DB->get_record('user_info_field', ['shortname' =>  'validationkey']);
$validationkeyid=$field->id;
$seatno=0;
$gencourseid = optional_param('id', null, PARAM_INT);

// We want to display our form.
//    $manager = new manager();
$gencourseId =$gencourseid;
    //echo  "userId-"  . $userId  . "userId-"  . $id;
    
    //$userId = $mform->userid;//optional_param('id', $USER->id, PARAM_INT);    // User id.
$rs = $DB->get_recordset_sql('select id from mdl_groups where courseid=' . $gencourseId);

        foreach ($rs as $gengroupid) {
            $recordsfound = true;
            $rsgm = $DB->get_recordset_sql('select userid from mdl_groups_members where groupid=' . $gengroupid->id);
            foreach ($rsgm  as $genuserid) {
                $userId=$genuserid->userid;
                //echo '>>>>field id>' . $fieldid . ">>>";
                $user = $DB->get_record('user_info_data', ['userid' =>  $userId , 'fieldid' =>  $validationkeyid]);
                //echo '>>>>old data>>' . $user->data . ">>>";
                $seatno=$seatno+1;
                $user->data = $seatno;
        
                $DB->update_record('user_info_data', $user, $bulk=false);


            }
            
            
        }


      


    // Go back to manage.php page
redirect($CFG->wwwroot . '/local/genseatno/manage.php');
///}


//echo $OUTPUT->header();
//$mform->display();
//echo $OUTPUT->footer();
