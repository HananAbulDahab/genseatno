<?php

if ($hassiteconfig) { // needs this condition or there is error on login page

    $ADMIN->add('localplugins', new admin_category('local_genseatno_category', get_string('pluginname', 'local_genseatno')));

    $settings = new admin_settingpage('local_genseatno', get_string('pluginname', 'local_genseatno'));
    $ADMIN->add('local_genseatno_category', $settings);

    $settings->add(new admin_setting_configcheckbox('local_genseatno/enabled',
        get_string('setting_enable', 'local_genseatno'), get_string('setting_enable_desc', 'local_genseatno'), '1'));

    $ADMIN->add('local_genseatno_category', new admin_externalpage('local_genseatno_manage', get_string('manage', 'local_genseatno'),
        $CFG->wwwroot . '/local/genseatno/manage.php'));
}
