<?php

/**
 * Plugin strings are defined here.
 *
 * @package     local_genseatno
 * @category    string
 * @copyright   2024 iqraa <iqraa@iqraa.edu>
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Manage seat no';

//$string['pluginname'] = 'genseatno';
$string['manage'] = 'Manage gen seat no';
$string['setting_enable'] = 'Enable';
$string['setting_enable_desc'] = 'Disable to stop ';
$string['genseatno:view'] = 'Manage gen seat no';
$string['manage_genseatno'] = 'Manage gen seat no';



$string['genseatno:managegenseatno'] = 'Manage gen seat no';


